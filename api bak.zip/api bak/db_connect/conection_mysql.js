const { MongoClient } = require('mongodb');
//let connection
const uri = "mongodb+srv://TeemoPatriarca:soyleyenda666@cluster0.ub68j.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";

console.log("Entro a mongoDB ")
connection = MongoClient.connect(uri, function (err, db) {
  if (err) {
    throw err;
  }
  return db
});

module.exports = connection;

/*const mysql = require("mysql");

// Create a connection to the database
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'TeemoPatriarca',
    password: 'soyleyenda666',
    database: 'db_mangalgtb',
    port: 3306,
});

// open the MySQL connection
connection.connect(error => {
    if (error) throw error;
    console.log("Successfully connected to the database.");
});

*/
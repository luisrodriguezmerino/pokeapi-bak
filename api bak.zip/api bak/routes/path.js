const express = require('express');
const router = express.Router();
const { MongoClient } = require('mongodb');
const client = new MongoClient("mongodb+srv://TeemoPatriarca:soyleyenda666@cluster0.ub68j.mongodb.net/myFirstDatabase?retryWrites=true&w=majority");

router.get('/all_paths', function (req, res, next) {

  async function run() {
    try {
      await client.connect();
      const database = client.db('Noticias_Web');
      const collection = database.collection('NoticiasData');
      const query = {};
      const response = collection.find(query);

      let responseArray = []
      await response.forEach((data) => {
        responseArray = [data, ...responseArray]
      })
      res.send(responseArray)
    } finally {
      await client.close();
    }
  }
  run().catch(console.dir);




  //console.log("Entro a mongoDB 2 ")
  /*connection = MongoClient.connect('mongodb+srv://TeemoPatriarca:soyleyenda666@cluster0.ub68j.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', function(err, db) {
  if (err) {
    throw err;
  }
  db.collection('NoticiasData').find().toArray(function(err, result) {
    if (err) {
      throw err;
    }
    res.send(result)
  });
  });*/
})

//conection_mysql.end();

module.exports = router;

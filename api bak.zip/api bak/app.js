const express = require('express');
const cors = require('cors')
const createError = require('http-errors');
const multer = require('multer');
const upload = multer();
const cookieParser = require('cookie-parser');
const registerHttp = require('morgan');
const path = require('path')
const fs = require('fs')

//1.INSTANCE EXPRESS
const app = express();

//2.ADD HEADERS WITH CORS FROM API
const corsOptions = {
  origin: '*',
  "methods": "GET,HEAD,PUT,PATCH,POST,DELETE",
  "preflightContinue": false,
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
}
app.use(cors(corsOptions))

//3.CONFIGURE JSON
app.use(express.json());// for parsing application/json
app.use(express.urlencoded({ extended: true }));// for parsing application/xwww-
app.use(upload.array());// for parsing multipart/form-data
app.use(cookieParser());
app.use(registerHttp(':remote-addr :remote-user :date[clf] :method :url :status => :response-time[3]ms response - :total-time[3]ms total'));
let accessLogStream = fs.createWriteStream(path.join(__dirname, 'access.log'), { flags: 'a' })
app.use(registerHttp(
  ':remote-addr :remote-user :date[clf] :method :url :status => :response-time[3]ms response - :total-time[3]ms total',
  { stream: accessLogStream }
))

//4.ROUTES FROM APP
const path_notice = require('./routes/path');

app.use('/api/path', path_notice);
/*app.use('/api/ver_manga', ver_mangas)
app.use('/api/filters', filters)
app.use('/api/mangasearch', mangasearch)*/

//5.MESSAGE ERROR
app.use(function (req, res, next) {
  next(createError(404));
});
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.send({
    message: err.message,
    error: err
  });
  return;
});

module.exports = app;
